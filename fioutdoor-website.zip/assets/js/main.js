
// Mobile nav toggle
const header = document.querySelector('header');
const toggle = document.querySelector('#mobileToggle');
if (toggle){
  toggle.addEventListener('click', () => {
    document.body.classList.toggle('mobile-open');
    toggle.setAttribute('aria-expanded', document.body.classList.contains('mobile-open'));
  });
}

// Smooth scroll fix for sticky header
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href').slice(1);
    const target = document.getElementById(id);
    if (target){
      e.preventDefault();
      const y = target.getBoundingClientRect().top + window.scrollY - 72;
      window.scrollTo({ top: y, behavior: 'smooth' });
      document.body.classList.remove('mobile-open');
    }
  });
});

// Contact form -> mailto:
const form = document.getElementById('contactForm');
if (form){
  form.addEventListener('submit', e => {
    e.preventDefault();
    const data = new FormData(form);
    const name = encodeURIComponent(data.get('name') || '');
    const phone = encodeURIComponent(data.get('phone') || '');
    const email = encodeURIComponent(data.get('email') || '');
    const service = encodeURIComponent(data.get('service') || '');
    const message = encodeURIComponent(data.get('message') || '');
    const subject = `[Quote Request] ${decodeURIComponent(service)} — ${decodeURIComponent(name)}`;
    const body = `Name: ${decodeURIComponent(name)}%0D%0A`
               + `Phone: ${decodeURIComponent(phone)}%0D%0A`
               + `Email: ${decodeURIComponent(email)}%0D%0A`
               + `Service: ${decodeURIComponent(service)}%0D%0A%0D%0A`
               + `${decodeURIComponent(message)}`;
    const mail = (form.dataset.to || 'replace-me@example.com');
    window.location.href = `mailto:${mail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });
}

// Year in footer
const y = document.getElementById('year');
if (y) y.textContent = new Date().getFullYear();

// Optional: register service worker for basic offline cache
if ('serviceWorker' in navigator){
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch(()=>{});
  });
}
